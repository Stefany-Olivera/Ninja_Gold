import random
import datetime
from flask import Flask, render_template, request, redirect, session, flash, url_for
app = Flask(__name__)
app.secret_key = "hrwufhjthwgaih"

@app.route("/")
def index():
	if "gold" not in session:
		session["gold"] = 0
	if "activities" not in session:
		session["activities"] = ""
	return render_template("index1.html")

@app.route('/clear')
def clear():
	session["gold"]=0
	session["activities"]=[]
	return redirect("/")

@app.route("/process_money",methods=["POST"])
def process():
	time = "({:%Y-%m-%d %I:%M:%S %p})".format(datetime.datetime.now())
	if request.form["box"] == "farm":
		gold_add = random.randrange(10,21)
		session["gold"] += gold_add
		act_add = "Earned " +str(gold_add)+ " gold(s) at the farm! " +time+ "\n"
		session["activities"].append(act_add) 
		print time
		print act_add
		print gold_add
	elif request.form["box"] == "cave":
		gold_add = random.randrange(5,11)
		session["gold"] += gold_add
		act_add = "Earned " +str(gold_add)+ " golds in the cave! " +time+ "\n"
		session["activities"].append(act_add) 
		print gold_add
	elif request.form["box"] == "house":
		gold_add = random.randrange(2,6)
		session["gold"] += gold_add
		act_add = "Earned " +str(gold_add)+ " golds in the house! " +time+ "\n"
		session["activities"].append(act_add) 
		print gold_add
	elif request.form["box"] == "casino":
		gold_add= random.randrange(-50,51)
		session["gold"] += gold_add
		if gold_add >-1:
			act_add = "Earned " +str(gold_add)+ " golds at the casino! " +time+ "\n"
			session["activities"].append(act_add) 
		else:
			gold_add = abs(gold_add)
			act_add = "Entered a casino and lost " +str(gold_add)+ " golds... Ouch. " +time+ "\n"
			session["activities"].append(act_add) 
		print gold_add


	return redirect("/")
app.run(debug=True)
